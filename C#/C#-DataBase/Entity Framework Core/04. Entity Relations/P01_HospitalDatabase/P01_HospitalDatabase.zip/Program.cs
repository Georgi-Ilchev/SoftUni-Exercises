﻿using P01_HospitalDatabase.Data;
using System;

namespace P01_HospitalDatabase
{
    class Program
    {
        static void Main(string[] args)
        {
            //var db = new HospitalContext();

            //db.Database.EnsureDeleted();
            //db.Database.EnsureCreated();

            //Uninstall-Package Microsoft.EntityFrameworkCore.Tools -r
        }
    }
}
