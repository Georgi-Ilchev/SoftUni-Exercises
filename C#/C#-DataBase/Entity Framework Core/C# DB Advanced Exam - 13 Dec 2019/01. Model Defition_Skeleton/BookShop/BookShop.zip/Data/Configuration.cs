﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-L3ARJIL\SQLEXPRESS;Database=BookShop;Trusted_Connection=True";
    }
}