﻿namespace Pr._04.WildFarm.Foods
{
    public class Vegetable : Food
    {
        public Vegetable(int quantity) : base(quantity)
        {
        }
    }
}
