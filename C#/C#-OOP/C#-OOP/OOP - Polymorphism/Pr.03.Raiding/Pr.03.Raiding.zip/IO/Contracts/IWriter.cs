﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pr._03.Raiding.IO.Contracts
{
    public interface IWriter
    {
        void Write(string text);
    }
}
