﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pr._03.Raiding.IO.Contracts
{
    public interface IReader
    {
        string Read();
    }
}
