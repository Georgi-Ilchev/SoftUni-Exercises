﻿using Pr._03.Raiding.Core;
using Pr._03.Raiding.Heroes;


namespace Pr._03.Raiding
{
    public class Program
    {
        static void Main(string[] args)
        {
            Engine egine = new Engine();
            egine.Run();
        }
    }
}
