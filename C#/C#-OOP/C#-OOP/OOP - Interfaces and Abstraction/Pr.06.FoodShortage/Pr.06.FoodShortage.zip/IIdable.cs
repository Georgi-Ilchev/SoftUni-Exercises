﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pr._06.FoodShortage
{
    public interface IIdable
    {
        public string Id { get; set; }
    }
}
