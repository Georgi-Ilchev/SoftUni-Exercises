﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pr._06.FoodShortage
{
    public interface IBirthable
    {
        public string Birthdate { get; set; }
    }
}
