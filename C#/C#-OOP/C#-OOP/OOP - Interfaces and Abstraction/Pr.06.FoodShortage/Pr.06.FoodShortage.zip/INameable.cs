﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pr._06.FoodShortage
{
    public interface INameable
    {
        string Name { get; set; }
    }
}
