﻿using Pr._08.CollectionHierarchy.Controllers;
using System;

namespace Pr._08.CollectionHierarchy
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
