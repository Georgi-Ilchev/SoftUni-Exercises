﻿namespace Pr._08.CollectionHierarchy.Interfaces
{
    public interface IAddCollection<T>
    {
        public int Add(T element);
    }
}
