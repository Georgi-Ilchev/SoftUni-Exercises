﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pr._07.MilitaryElite
{
    public interface IEngineer
    {
        List<Repair> Repairs { get; }
    }
}
