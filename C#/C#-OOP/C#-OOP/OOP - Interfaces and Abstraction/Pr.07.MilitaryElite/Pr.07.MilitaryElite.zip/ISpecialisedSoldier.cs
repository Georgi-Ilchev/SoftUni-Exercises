﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pr._07.MilitaryElite
{
    public interface ISpecialisedSoldier
    {
        public string Corps { get;}
    }
}
