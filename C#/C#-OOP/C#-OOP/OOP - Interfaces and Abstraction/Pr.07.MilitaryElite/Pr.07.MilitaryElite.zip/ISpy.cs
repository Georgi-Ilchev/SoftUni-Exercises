﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pr._07.MilitaryElite
{
    public interface ISpy
    {
        public int CodeNumber { get;}
    }
}
