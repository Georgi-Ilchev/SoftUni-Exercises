﻿namespace OOP___Interfaces_and_Abstraction
{
    public interface IBrowsable
    {
        string Browse(string webSite);
    }
}
