﻿namespace OOP___Interfaces_and_Abstraction
{
    public interface ICalable
    {
        string Call(string phone);
    }
}
