﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pr._05.BirthdayCelebrations
{
    public interface IBirthable
    {
        public string Birthdate { get; set; }
    }
}
