﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pr._05.BirthdayCelebrations
{
    public interface IIdable
    {
        public string Id { get; set; }
    }
}
