﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pr._04.BorderControl
{
    public interface IIdable
    {
        public string Id { get; set; }
    }
}
