﻿namespace ShoppingSpree.v2.Common
{
    public static class GlobalConstants
    {
        public const string EmptyNameExcMsg = "Name cannot be empty";
        public const string NegativeMoneyExcMsg = "Money cannot be negative";
    }
}
