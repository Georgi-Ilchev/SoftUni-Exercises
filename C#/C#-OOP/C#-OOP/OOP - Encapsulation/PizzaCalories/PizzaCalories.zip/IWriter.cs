﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PizzaCalories
{
    public interface IWriter
    {
        void WriteLine(string textLine);
    }
}
