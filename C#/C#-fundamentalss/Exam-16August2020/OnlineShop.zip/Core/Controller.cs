﻿using OnlineShop.Common.Constants;
using OnlineShop.Common.Enums;
using OnlineShop.Models.Products.Components.ChildClasses;
using OnlineShop.Models.Products.Computers;
using OnlineShop.Models.Products.Computers.ChildClasses;
using OnlineShop.Models.Products.Peripherals;
using System;
using System.Collections.Generic;
using IComponent = OnlineShop.Models.Products.Components.IComponent;
using System.ComponentModel;
using System.Linq;
using System.Text;
using OnlineShop.Models.Products.Peripherals.ChildClasses;

namespace OnlineShop.Core
{
    public class Controller : IController
    {
        //private ICollection<IComputer> computers;
        //private ICollection<IComponent> components;
        //private ICollection<IPeripheral> peripherals;

        //public Controller()
        //{
        //    this.computers = new List<IComputer>();
        //    this.components = new List<IComponent>();
        //    this.peripherals = new List<IPeripheral>();
        //}

        //public string AddComponent(int computerId, int id, string componentType, string manufacturer, string model, decimal price, double overallPerformance, int generation)
        //{
        //    //OnlineShop.Models.Products.Components.IComponent component = null;
        //    IComponent component = null;

        //    if (componentType == ComponentType.CentralProcessingUnit.ToString())
        //    {
        //        component = new CentralProcessingUnit(id, manufacturer, model, price, overallPerformance, generation);
        //    }
        //    else if (componentType == ComponentType.Motherboard.ToString())
        //    {
        //        component = new Motherboard(id, manufacturer, model, price, overallPerformance, generation);
        //    }
        //    else if (componentType == ComponentType.PowerSupply.ToString())
        //    {
        //        component = new PowerSupply(id, manufacturer, model, price, overallPerformance, generation);
        //    }
        //    else if (componentType == ComponentType.RandomAccessMemory.ToString())
        //    {
        //        component = new RandomAccessMemory(id, manufacturer, model, price, overallPerformance, generation);
        //    }
        //    else if (componentType == ComponentType.SolidStateDrive.ToString())
        //    {
        //        component = new SolidStateDrive(id, manufacturer, model, price, overallPerformance, generation);
        //    }
        //    else if (componentType == ComponentType.VideoCard.ToString())
        //    {
        //        component = new VideoCard(id, manufacturer, model, price, overallPerformance, generation);
        //    }
        //    else
        //    {
        //        throw new ArgumentException(ExceptionMessages.InvalidComponentType);
        //    }

        //    this.EnsureComponentIdIsUnique(id);

        //    var computer = IsComputersIdExist(computerId);

        //    computer.AddComponent(component);
        //    this.components.Add(component);

        //    return string.Format(SuccessMessages.AddedComponent, componentType, id, computerId);
        //}

        //public string AddComputer(string computerType, int id, string manufacturer, string model, decimal price)
        //{
        //    IComputer computer = null;

        //    if (computerType == ComputerType.DesktopComputer.ToString())
        //    {
        //        computer = new DesktopComputer(id, manufacturer, model, price);
        //    }
        //    else if (computerType == ComputerType.Laptop.ToString())
        //    {
        //        computer = new Laptop(id, manufacturer, model, price);
        //    }
        //    else
        //    {
        //        throw new ArgumentException(ExceptionMessages.InvalidComputerType);
        //    }

        //    if (this.computers.Any(x => x.Id == id))
        //    {
        //        throw new ArgumentException(ExceptionMessages.ExistingComputerId);
        //    }

        //    this.computers.Add(computer);
        //    return string.Format(SuccessMessages.AddedComputer, id);
        //}

        //public string AddPeripheral(int computerId, int id, string peripheralType, string manufacturer, string model, decimal price, double overallPerformance, string connectionType)
        //{
        //    IPeripheral peripheral = null;

        //    if (peripheralType == PeripheralType.Headset.ToString())
        //    {
        //        peripheral = new Headset(id, manufacturer, model, price, overallPerformance, connectionType);
        //    }
        //    else if (peripheralType == PeripheralType.Keyboard.ToString())
        //    {
        //        peripheral = new Keyboard(id, manufacturer, model, price, overallPerformance, connectionType);
        //    }
        //    else if (peripheralType == PeripheralType.Monitor.ToString())
        //    {
        //        peripheral = new Monitor(id, manufacturer, model, price, overallPerformance, connectionType);
        //    }
        //    else if (peripheralType == PeripheralType.Mouse.ToString())
        //    {
        //        peripheral = new Mouse(id, manufacturer, model, price, overallPerformance, connectionType);
        //    }
        //    else
        //    {
        //        throw new ArgumentException(ExceptionMessages.InvalidPeripheralType);
        //    }

        //    if (this.peripherals.Any(x => x.Id == id))
        //    {
        //        throw new ArgumentException(ExceptionMessages.ExistingPeripheralId);
        //    }

        //    var computer = IsComputersIdExist(computerId);
        //    computer.AddPeripheral(peripheral);
        //    this.peripherals.Add(peripheral);

        //    return string.Format(SuccessMessages.AddedPeripheral, peripheralType, id, computerId);
        //}

        //public string BuyBest(decimal budget)
        //{
        //    if (this.computers.Count == 0)
        //    {
        //        throw new ArgumentException(string.Format(ExceptionMessages.CanNotBuyComputer, budget));
        //    }

        //    IComputer computer = this.computers
        //        .Where(x => x.Price <= budget)
        //        .OrderByDescending(x => x.OverallPerformance)
        //        .FirstOrDefault();

        //    if (computer == null)
        //    {
        //        throw new ArgumentException(string.Format(ExceptionMessages.CanNotBuyComputer, budget));
        //    }

        //    var result = computer.ToString();
        //    this.computers.Remove(computer);

        //    return result;
        //}

        //public string BuyComputer(int id)
        //{
        //    var computer = IsComputersIdExist(id);

        //    var result = computer.ToString();
        //    this.computers.Remove(computer);

        //    return result;
        //}

        //public string GetComputerData(int id)
        //{
        //    var computer = IsComputersIdExist(id);

        //    return computer.ToString();
        //}

        //public string RemoveComponent(string componentType, int computerId)
        //{
        //    var computer = IsComputersIdExist(computerId);
        //    computer.RemoveComponent(componentType);

        //    var component = this.components.FirstOrDefault(x => x.GetType().Name == componentType);
        //    if (component != null)
        //    {
        //        this.components.Remove(component);
        //    }

        //    return string.Format(SuccessMessages.RemovedComponent, componentType, component.Id);
        //}

        //public string RemovePeripheral(string peripheralType, int computerId)
        //{
        //    var computer = IsComputersIdExist(computerId);
        //    computer.RemovePeripheral(peripheralType);

        //    var peripheral = this.peripherals.FirstOrDefault(x => x.GetType().Name == peripheralType);
        //    if (peripheral != null)
        //    {
        //        this.peripherals.Remove(peripheral);
        //    }

        //    return string.Format(SuccessMessages.RemovedPeripheral, peripheralType, peripheral.Id);
        //}



        //public IComputer IsComputersIdExist(int computerId)
        //{
        //    var computer = this.computers.FirstOrDefault(x => x.Id == computerId);

        //    if (computer == null)
        //    {
        //        throw new ArgumentException(ExceptionMessages.NotExistingComputerId);
        //    }

        //    return computer;
        //}

        //private void EnsureComponentIdIsUnique(int id)
        //{
        //    if (this.components.Any(x => x.Id == id))
        //    {
        //        throw new ArgumentException(ExceptionMessages.ExistingComponentId);
        //    }
        //}

        private ICollection<IComputer> computers;
        private ICollection<IComponent> components;
        private ICollection<IPeripheral> peripherals;
        public Controller()
        {
            this.computers = new List<IComputer>();
            this.components = new List<IComponent>();
            this.peripherals = new List<IPeripheral>();
        }

        public string AddComputer(string computerType, int id, string manufacturer, string model, decimal price)
        {
            if (this.computers.Any(c => c.Id == id))
            {
                throw new ArgumentException(ExceptionMessages.ExistingComputerId);
            }

            IComputer computer = CreateComputer(id, manufacturer, model, price, computerType);

            this.computers.Add(computer);

            string outputMsg = string.Format(SuccessMessages.AddedComputer, id);

            return outputMsg;
        }
        public string AddComponent(int computerId, int id, string componentType, string manufacturer, string model, decimal price, double overallPerformance, int generation)
        {
            if (this.components.Any(c =>/* c.GetType().Name == componentType ||*/ c.Id == id))
            {
                throw new ArgumentException(ExceptionMessages.ExistingComponentId);
            }

            IComponent component = CreateComponent(id, componentType, manufacturer, model, price, overallPerformance, generation);
            IComputer computer = CheckIfComputerExistAndExtractIt(computerId);
            this.components.Add(component);
            computer.AddComponent(component);

            string outputMsg = string.Format(SuccessMessages.AddedComponent, componentType, id, computerId);

            return outputMsg;
        }

        public string AddPeripheral(int computerId, int id, string peripheralType, string manufacturer, string model, decimal price, double overallPerformance, string connectionType)
        {
            if (this.peripherals.Any(p => p.Id == id))
            {
                throw new ArgumentException(ExceptionMessages.ExistingPeripheralId);
            }

            IPeripheral peripheral = CreatePeripheral(id, peripheralType, manufacturer, model, price, overallPerformance, connectionType);

            IComputer computer = CheckIfComputerExistAndExtractIt(computerId);
            computer.AddPeripheral(peripheral);

            this.peripherals.Add(peripheral);
            string outputMsg = string.Format(SuccessMessages.AddedPeripheral, peripheralType, id, computerId);

            return outputMsg;

        }

        public string BuyBest(decimal budget)
        {
            IComputer computer = this.computers.OrderByDescending(c => c.OverallPerformance).ThenByDescending(c => c.Price).FirstOrDefault(c => c.Price <= budget);

            if (computer == null)
            {
                string excMsg = string.Format(ExceptionMessages.CanNotBuyComputer, budget);
                throw new ArgumentException(excMsg);
            }

            string output = computer.ToString();
            this.computers.Remove(computer);

            return output;
        }

        public string BuyComputer(int id)
        {
            IComputer computer = CheckIfComputerExistAndExtractIt(id);
            string output = computer.ToString();
            this.computers.Remove(computer);

            return output;
        }

        public string GetComputerData(int id)
        {
            IComputer computer = CheckIfComputerExistAndExtractIt(id);

            return computer.ToString();
        }

        public string RemoveComponent(string componentType, int computerId)
        {
            IComputer computer = CheckIfComputerExistAndExtractIt(computerId);
            IComponent component = computer.Components.FirstOrDefault(c => c.GetType().Name == componentType);

            computer.RemoveComponent(componentType);
            this.components.Remove(component);

            string outputMsg = string.Format(SuccessMessages.RemovedComponent, componentType, component.Id);

            return outputMsg;
        }

        public string RemovePeripheral(string peripheralType, int computerId)
        {
            IComputer computer = CheckIfComputerExistAndExtractIt(computerId);
            IPeripheral peripheral = computer.Peripherals.FirstOrDefault(p => p.GetType().Name == peripheralType);

            computer.RemovePeripheral(peripheralType);
            this.peripherals.Remove(peripheral);

            string outputMsg = string.Format(SuccessMessages.RemovedPeripheral, peripheralType, peripheral.Id);

            return outputMsg;

        }

        private IComputer CheckIfComputerExistAndExtractIt(int id)
        {
            if (!this.computers.Any(c => c.Id == id))
            {

                throw new ArgumentException(ExceptionMessages.NotExistingComputerId);
            }

            return this.computers.FirstOrDefault(c => c.Id == id);
        }

        private static IComputer CreateComputer(int id, string manufacturer, string model, decimal price, string computerType)
        {
            Enum.TryParse(computerType, out ComputerType compType);
            IComputer computer = compType switch
            {
                ComputerType.DesktopComputer => new DesktopComputer(id, manufacturer, model, price),
                ComputerType.Laptop => new Laptop(id, manufacturer, model, price),
                _ => throw new ArgumentException(ExceptionMessages.InvalidComputerType)
            };

            return computer;
        }

        private static IComponent CreateComponent(int id, string componentType, string manufacturer, string model, decimal price, double overallPerformance, int generation)
        {
            Enum.TryParse(componentType, out ComponentType typeOfComponent);
            IComponent component = typeOfComponent switch
            {
                ComponentType.CentralProcessingUnit => new CentralProcessingUnit(id, manufacturer, model, price, overallPerformance, generation),
                ComponentType.Motherboard => new Motherboard(id, manufacturer, model, price, overallPerformance, generation),
                ComponentType.PowerSupply => new PowerSupply(id, manufacturer, model, price, overallPerformance, generation),
                ComponentType.RandomAccessMemory => new RandomAccessMemory(id, manufacturer, model, price, overallPerformance, generation),
                ComponentType.SolidStateDrive => new SolidStateDrive(id, manufacturer, model, price, overallPerformance, generation),
                ComponentType.VideoCard => new VideoCard(id, manufacturer, model, price, overallPerformance, generation),
                _ => throw new ArgumentException(ExceptionMessages.InvalidComponentType)
            };

            return component;
        }

        private static IPeripheral CreatePeripheral(int id, string peripheralType, string manufacturer, string model, decimal price, double overallPerformance, string connectionType)
        {
            Enum.TryParse(peripheralType, out PeripheralType typeOfPeripheral);
            IPeripheral peripheral = typeOfPeripheral switch
            {
                PeripheralType.Headset => new Headset(id, manufacturer, model, price, overallPerformance, connectionType),
                PeripheralType.Keyboard => new Keyboard(id, manufacturer, model, price, overallPerformance, connectionType),
                PeripheralType.Monitor => new Monitor(id, manufacturer, model, price, overallPerformance, connectionType),
                PeripheralType.Mouse => new Mouse(id, manufacturer, model, price, overallPerformance, connectionType),
                _ => throw new ArgumentException(ExceptionMessages.InvalidPeripheralType)
            };

            return peripheral;
        }
    }
}
